import React, { useContext, useState, useEffect } from "react";
import { Avatar, Button } from "@material-ui/core";
import DeleteIcon from "@mui/icons-material/Delete";
import { multiStepContext } from "../StepContext";
import axios from "axios";

function ImageUploader({ user }) {
  // console.log(user,"image")

  const [image, setImage] = useState(localStorage.getItem("uploadedImage"));

  // use efect for localStorage or sessionStorage
  useEffect(() => {
    // console.log('useEffect triggered');

    const url = localStorage.getItem("uploadedImage");
    const imageBlob = new Blob([url]);
    const imageSize = imageBlob.size;
    console.log(`Image size: ${imageSize} bytes`);

    console.log("url", url);

    if (url) {
      setImage(url);
    } else {
      setImage(user ? user.picture : "");
      localStorage.setItem("uploadedImage", user ? user.picture : "N");
    }
  }, [user ? user.picture : "N"]);

  const handleChange = async (image) => {
    const url = URL.createObjectURL(image);
    localStorage.setItem("uploadedImage", url);
    // this will replace the current URL with the selected file URL
    setImage(url);
  };

  const handleDelete = () => {
    // setImage(null);
    setImage(user ? user.picture : "N");
    localStorage.removeItem("uploadedImage");
  };

  // Handle APi  to post the image on specific url
  function handleApi() {
    const formData = new FormData();
    formData.append("image", image);
    axios
      .post("url", formData)
      .then((res) => {
        console.log(res);
      })
      .then((err) => {
        console.log(err, "url missing");
      });
  }

  return (
    <div className="d-flex align-items-center ">
      <input
        type="file"
        accept="image/*"
        style={{ display: "none" }}
        id="raised-button-file"
        // onChange={handleChange}
        // onClick={handleApi}
        onChange={(e) => handleChange(e.target.files[0])}
      />

      <div>
        {image && (
          <Avatar
            style={{
              border: "2px solid blue",
              width: "100px",
              height: "100px",
              marginLeft: "2rem",
              marginRight: "3rem",
            }}
            src={image}
            // src={canChangeImage ? URL.createObjectURL(image) : image}
            alt="Uploaded Image"
          />
        )}
      </div>
      {/* {image} */}
      <div>
        <label htmlFor="raised-button-file">
          <Button
            style={{ marginTop: "-3rem" }}
            variant="contained"
            color="primary"
            component="span"
          >
            change Photo
          </Button>
        </label>
        {image && (
          <Button
            style={{
              marginTop: "3.5rem",
              marginLeft: "-9.4rem",
              paddingRight: "2.3rem",
            }}
            variant="outlined"
            color="primary"
            onClick={handleDelete}
            startIcon={<DeleteIcon />}
          >
            Delete
          </Button>
        )}
      </div>
    </div>
  );
}

export default ImageUploader;
