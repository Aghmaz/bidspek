import React, { useState, useEffect, useContext } from "react";
import Button from "@mui/material/Button";
import { multiStepContext } from "../StepContext";

const Portfolio = () => {
  const { setStep, userData, setUserData } = useContext(multiStepContext);

  const [images, setImages] = useState(
    JSON.parse(localStorage.getItem("images")) || Array(4).fill(null)
  );
  const [selectedBox, setSelectedBox] = useState(null);

  const handleImageChange = (index, e) => {
    if (e && e.target && e.target.files && e.target.files.length > 0) {
      const newImages = [...images];
      // var file = e.target.files[0];
      // var reader = new FileReader();
      // reader.readAsDataURL(file);

      newImages[index] = URL.createObjectURL(e.target.files[0]);
      // newImages[index] = reader;
      // newImages[index] = e.target.files[0];

      setImages(newImages);
      setSelectedBox(null);
      console.log("images", JSON.stringify(newImages));
      localStorage.setItem("images", JSON.stringify(newImages));
    }
  };

  const handleImageCancel = () => {
    const newImages = [...images];
    newImages[selectedBox] = null;
    setImages(newImages);
    setSelectedBox(null);
    localStorage.setItem("images", JSON.stringify(newImages));
  };
  const handleReplacePhoto = (index) => {
    const fileInput = document.createElement("input");
    fileInput.type = "file";
    fileInput.accept = "image/*";
    fileInput.addEventListener("change", (e) => {
      handleImageChange(index, e);
    });
    fileInput.click();
  };

  const handleBoxClick = (index) => {
    setSelectedBox(index);
  };
  return (
    <div
      style={{ margin: "auto", width: "60%", marginBottom: "5rem" }}
      className="mb-3 mt-5"
    >
      <h3> Project Case Study</h3>
      <span>
        {" "}
        Share images of your previous work helps your potential clients see the
        quality of your work
      </span>
      <div style={{ display: "flex" }}>
        {[...Array(4)].map((_, index) => (
          <div key={index} style={{ margin: "10px" }}>
            <div
              style={{
                border: "1px solid blue",
                width: "80px",
                height: "80px",
                position: "relative",
                borderRadius: "0.5rem",
                opacity: selectedBox === index ? 0.5 : 1,
                border:
                  selectedBox === index ? "3px solid blue" : "2px solid blue",
              }}
              onClick={() => handleBoxClick(index)}
            >
              {images[index] && (
                <>
                  <img
                    src={images[index]}
                    // src={URL.createObjectURL(images[index])}
                    alt="uploaded"
                    style={{
                      width: "100%",
                      height: "100%",
                      objectFit: "cover",
                    }}
                  />
                </>
              )}
              {!images[index] && (
                <div style={{ position: "absolute", top: "1%", left: "30%" }}>
                  <label htmlFor={`image${index}`}>
                    <span style={{ fontSize: "50px", color: "blue" }}>+</span>
                    <input
                      style={{ display: "none" }}
                      type="file"
                      id={`image${index}`}
                      accept="image/*"
                      onChange={(e) => handleImageChange(index, e)}
                    />
                  </label>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
      <div className="row mt-2">
        <div className="col-sm-6 col-lg-4">
          <Button
            style={{
              paddingLeft: "3.4rem",
              paddingRight: "3.4rem",
              textTransform: "capitalize",
            }}
            variant="outlined"
            onClick={handleImageCancel}
          >
            delete
          </Button>
        </div>
        <div className="col-sm-6 col-lg-4">
          <Button
            style={{ textTransform: "capitalize" }}
            variant="contained"
            onClick={() => handleReplacePhoto(selectedBox)}
          >
            Change photo
          </Button>
        </div>
      </div>
      <br></br>
      <br></br>
      <br></br>
      <Button
        style={{
          paddingLeft: "4rem",
          paddingRight: "4rem",
          marginBottom: "1rem",
          border: "2px solid rgb(25, 118, 210)",
          color: "rgb(25, 118, 210)",
        }}
        className=" mb-3 mt-3"
        variant="outline-primary"
        type="submit"
        onClick={() => setStep(3)}
      >
        back
      </Button>
      <Button
        style={{
          float: "right",
          paddingLeft: "4rem",
          paddingRight: "4rem",
          marginBottom: "1rem",
          backgroundColor: "rgb(25, 118, 210)",
          color: "white",
        }}
        className=" mb-3 mt-3"
        type="submit"
        onClick={() => setStep(5)}
      >
        next
      </Button>
    </div>
  );
};

export default Portfolio;
