import React, { useContext, useState, useReducer, useEffect } from "react";
import { Card } from "react-bootstrap";
import Button from "@mui/material/Button";

import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
import Row from "react-bootstrap/Row";
import { multiStepContext } from "../StepContext";
import axios from "axios";

// for selection
const inisialState = [
  { title: "High Rise Condonminiums", flag: false },
  { title: "Parking Garages", flag: false },
  { title: "Office Buildings", flag: false },
  { title: "Low Rise Structure", flag: false },
  { title: "Floors & badge", flag: false },
  { title: "Marine Structure", flag: false },
  { title: "Underground tunnel & pipelines", flag: false },
];

const Professional = (props) => {
  const { setStep, userData, setUserData } = useContext(multiStepContext);

  const [selectedValue, setSelectedValue] = useState(
    localStorage.getItem("selectedValue") || ""
  );

  // new code for job title
  const handleChange = (event) => {
    const value = event.target.value;
    setSelectedValue(value);
    localStorage.setItem("selectedValue", value);
  };
  // use effect for job tittle
  useEffect(() => {
    const handleBeforeUnload = () => {
      localStorage.setItem("selectedValue", selectedValue);
    };
    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [selectedValue]);

  const [state, setState] = useState(
    JSON.parse(localStorage.getItem("professionalData")) || inisialState
  );

  function selectItem(item, index) {
    const tempSate = [...state];
    tempSate[index].flag = !tempSate[index].flag;
    setState(tempSate);
  }

  useEffect(() => {
    const selectedItems = state.filter((item) => item.flag);
    console.log(selectedItems);

    localStorage.setItem("professionalData", JSON.stringify(state));
  }, [state]);

  return (
    <div style={{ margin: "auto", width: "60%" }} className="mb-3 mt-5 ">
      <h5> Job Title</h5>
      <p className="mt-3" style={{ fontSize: "11px" }}>
        {" "}
        Pick the job title you identify with the most
      </p>

      <div>
        <div style={{ display: "flex", gap: "5px" }}>
          <Card
            style={{ width: "35%" }}
            className="bg-white  p-2 "
            md="4"
            variant="outline-primary"
          >
            <Form.Check
              inlineu
              label="Engineer"
              name="job-title"
              value="engineer"
              type="radio"
              checked={selectedValue === "engineer"}
              onChange={handleChange}
            />
          </Card>{" "}
          <Card
            style={{ width: "35%" }}
            className="bg-white  p-2"
            md="4"
            variant="outline-primary"
          >
            <Form.Check
              inline
              label="Contractor"
              name="job-title"
              value="contractor"
              type="radio"
              checked={selectedValue === "contractor"}
              onChange={handleChange}
            />
          </Card>{" "}
          <Card
            style={{ width: "35%" }}
            className="bg-white  p-2"
            md="4"
            variant="outline-primary"
          >
            <Form.Check
              inline
              label="Consultant"
              name="job-title"
              type="radio"
              value="consultant"
              disabled
              checked={selectedValue === "consultant"}
              onChange={handleChange}
            />
          </Card>{" "}
        </div>
        <h5 className="mt-3"> My Specialty</h5>
        <p className="mt-3" style={{ fontSize: "11px" }}>
          Add the types of infrastructure projects that are most interesting to
          you
        </p>
        <h6 className="mt-5"> Specify your preference</h6>

        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
          }}
        >
          {state.map((item, index) => {
            return (
              <div
                key={index}
                style={{
                  border: "solid 0.5px #1976d2",
                  margin: "10px",
                  paddingLeft: "3rem",
                  paddingRight: "3rem",
                  borderRadius: "25px",
                  paddingTop: "0.5rem",
                  paddingBottom: "0.5rem",
                  backgroundColor: `${item.flag ? "#1976d2" : "inherit"}`,
                  boxShadow: `${
                    item.flag ? "-1px 2px 10px -1px grey" : "0px 0px 0px 0px"
                  }`,
                  cursor: "pointer",
                }}
                onClick={() => selectItem(item, index)}
              >
                <p
                  style={{
                    margin: "0px",
                    color: `${item.flag ? "white" : "#1976d2"}`,
                  }}
                >
                  {item.title}
                </p>
              </div>
            );
          })}
        </div>

        <Button
          style={{
            paddingLeft: "4rem",
            paddingRight: "4rem",
            marginBottom: "1rem",
            border: "2px solid rgb(25, 118, 210)",
          }}
          className=" mb-3 mt-3"
          variant="outline-primary"
          type="submit"
          onClick={() => setStep(1)}
        >
          back
        </Button>
        <Button
          style={{
            float: "right",
            paddingLeft: "4rem",
            paddingRight: "4rem",
            marginBottom: "1rem",
            backgroundColor: "rgb(25, 118, 210)",
            color: "white",
          }}
          className=" mb-3 mt-3"
          type="submit"
          onClick={() => setStep(3)}
        >
          next
        </Button>
      </div>
    </div>
  );
};

export default Professional;
