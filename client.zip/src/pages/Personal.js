import React, { useContext, useState, useEffect } from "react";
import Button from "@mui/material/Button";

import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
import Row from "react-bootstrap/Row";
import { multiStepContext } from "../StepContext";
import ImageUploader from "./ImageUploader";
import "./personal.css";
import { ToastContainer, toast } from "react-toastify";

// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faCheckSquareO } from '@fortawesome/free-solid-svg-icons';

const Personal = ({ user }) => {
  // console.log(user,"personal")

  const [selectedValue, setSelectedValue] = useState(
    localStorage.getItem("occupation") || ""
  );

  // new code for Occuptation
  const handleChange = (event) => {
    const value = event.target.value;
    setSelectedValue(value);
    localStorage.setItem("occupation", value);
    setInputValue("");
  };

  const handleInputChange = (event) => {
    const value = event.target.value;
    setInputValue(value);
    localStorage.setItem("company_name", value);
  };
  useEffect(() => {
    const storedCompanyValue = localStorage.getItem("company_name");
    if (storedCompanyValue) {
      setInputValue(storedCompanyValue);
    }
  }, []);

  // use effect for Occuptation
  useEffect(() => {
    const handleBeforeUnload = () => {
      localStorage.setItem("selectedValue", selectedValue);
    };
    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [selectedValue]);

  // phone number selection
  const [switchValue, setSwitchValue] = useState(false);

  useEffect(() => {
    const storedValue = localStorage.getItem("switchValue");
    if (storedValue !== null) {
      setSwitchValue(JSON.parse(storedValue));
    }
  }, []);

  const handleSwitchToggle = () => {
    const newValue = !switchValue;
    setSwitchValue(newValue);
    localStorage.setItem("switchValue", JSON.stringify(newValue));
  };

  const { setStep, userData, setUserData } = useContext(multiStepContext);

  const [inputValue, setInputValue] = useState("");
  const [isInputValid, setIsInputValid] = useState(false);

  // Validation checks on each input

  const validateField = (fieldName) => {
    // setIsInputValid(validateField(fieldName));
    const value = userData[fieldName];
    if (!value) {
      // If the value is empty, the field is invalid
      return false;
    }
    if (fieldName === "lastname") {
      const pattern = /^[A-Za-z]+(?:\s?[A-Za-z]+)*$/;
      return pattern.test(value);
    }
    // if (fieldName === 'email') {
    //   // Check if the value is a valid email address
    //   const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    //   return pattern.test(value);
    // }
    if (fieldName === "phone") {
      // Check if the value is a valid phone number
      // const pattern = /^(\+91|91)?[6-9]\d{9}$/;
      const pattern = /^\+(?:[0-9]●?){6,14}[0-9]$/;
      return pattern.test(value);
    }
    if (fieldName === "address") {
      // Check if the value is a valid address
      const pattern = /^[a-zA-Z0-9\s,'-]*$/;
      return pattern.test(value);
    }
    if (fieldName === "city" || fieldName === "state") {
      // Check if the value contains only letters and spaces
      const pattern = /^[a-zA-Z\s]*$/;
      return pattern.test(value);
    }
    if (fieldName === "zip") {
      // Check if the value is a valid zip code
      const pattern = /^\d{5}(?:[-\s]\d{4})?$/;
      return pattern.test(value);
    }

    // Check if the value contains only letters, first character capital, and length is more than three
    const namePattern = /^[A-Z][a-zA-Z]{2,}$/;
    return namePattern.test(value);
  };

  // toaster messages
  const firstName = () => toast("Please Enter the Name");

  return (
    <div style={{ margin: "auto", width: "60%" }} className="mb-3 mt-5 ">
      <h5> My Profile</h5>
      <p className="mt-3" style={{ fontSize: "11px" }}>
        {" "}
        Start by filling your personal information
      </p>
      <h5 className="mt-4">Profile Photo</h5>
      <div className="rounded">
        <ImageUploader user={user} />
        <p className="mt-3" style={{ fontSize: "11px" }}>
          Add your profile photo.The recommended size is 300 x 300px.
        </p>
      </div>
      <div>
        <Form>
          <Row className="mb-3">
            <Form.Group as={Col} md="6">
              <Form.Label>First Name*</Form.Label>
              <Form.Control
                required
                type="text"
                placeholder="First Name"
                defaultValue={user ? user.given_name : ""}
                value={userData["firstname"]}
                onChange={(e) =>
                  setUserData({ ...userData, firstname: e.target.value })
                }
                // isValid={validateField('firstname')}
                // isInvalid={!validateField('firstname')}
              />

              {/* <Form.Control.Feedback type="valid">
                Looks good!
              </Form.Control.Feedback>
              <Form.Control.Feedback type="invalid">
                Please enter a valid first name.
              </Form.Control.Feedback> */}
            </Form.Group>

            <Form.Group as={Col} md="6">
              <Form.Label>Last Name*</Form.Label>
              <Form.Control
                required
                type="text"
                placeholder="Last Name"
                value={userData["lastname"]}
                defaultValue={user ? user.family_name : " "}
                onChange={(e) =>
                  setUserData({ ...userData, lastname: e.target.value })
                }
                // isValid={validateField('lastname')}
                // isInvalid={!validateField('lastname')}
              />
              {/* <Form.Control.Feedback type="valid">
                Looks good!
              </Form.Control.Feedback>
              <Form.Control.Feedback type="invalid">
                Please enter a valid last name.
              </Form.Control.Feedback> */}
            </Form.Group>
          </Row>

          <Row className="mb-3">
            <Form.Group as={Col} md="6">
              <Form.Label>Email*</Form.Label>
              <Form.Control
                // required
                type="email"
                // placeholder="jack.offer@joengineering.com"
                defaultValue={user ? user.email : ""}
                // disabled
                value={userData["email"]}
                onChange={(e) =>
                  setUserData({ ...userData, email: e.target.value })
                }
                // isValid={validateField('email')}
                // isInvalid={!validateField('email')}
              />
              {/* <Form.Control.Feedback type="valid">Looks good!</Form.Control.Feedback>
              <Form.Control.Feedback type="invalid">
                Please enter a valid email.
              </Form.Control.Feedback> */}

              <Form.Check
                inline
                label="company"
                value="company"
                type="radio"
                checked={selectedValue === "company"}
                onChange={handleChange}
              />
              <Form.Check
                className="ms-5 mt-2"
                inline
                label="personal"
                value="personal"
                type="radio"
                checked={selectedValue === "personal"}
                onChange={handleChange}
              />

              {selectedValue === "company" && (
                <div className="mt-2">
                  <Form.Group as={Col} md="6">
                    <Form.Control
                      required
                      type="text"
                      placeholder="company name"
                      value={inputValue}
                      onChange={handleInputChange}
                      // isValid={validateField('lastname')}
                      // isInvalid={!validateField('lastname')}
                    />
                    {/* <Form.Control.Feedback type="valid">
                      Looks good!
                    </Form.Control.Feedback>
                    <Form.Control.Feedback type="invalid">
                      Please enter a valid last name.
                    </Form.Control.Feedback> */}
                  </Form.Group>{" "}
                </div>
              )}
              {/* <Form.Control.Feedback>Looks good!</Form.Control.Feedback> */}
            </Form.Group>
            <Form.Group as={Col} md="6">
              <Form.Label>Phone Number</Form.Label>
              <Form.Control
                // optional
                // required
                type="text"
                placeholder="Optional"
                value={userData["phone"]}
                onChange={(e) =>
                  setUserData({ ...userData, phone: e.target.value })
                }
                // isValid={validateField('phone')}
                // isInvalid={!validateField('phone')}
              />
              <Form.Control.Feedback type="valid">
                Looks good!
              </Form.Control.Feedback>
              <Form.Control.Feedback type="invalid">
                Please Enter the correct number
              </Form.Control.Feedback>
              <Form.Check
                className="mt-2 check"
                type="switch"
                id="custom-switch"
                label="Display Phone number in public profile "
                checked={switchValue}
                onChange={handleSwitchToggle}
              />
            </Form.Group>
          </Row>

          <Row className="mb-3">
            <Form.Group as={Col} md="12">
              <Form.Label>Address*</Form.Label>
              <Form.Control
                type="text"
                placeholder="optional"
                optional
                // onChange={handleChange}
                value={userData["address"]}
                onChange={(e) =>
                  setUserData({ ...userData, address: e.target.value })
                }
                // isValid={validateField('address')}
                // isInvalid={!validateField('address')}
              />
              {/* <Form.Control.Feedback type="valid">
                looks good .!
              </Form.Control.Feedback>
              <Form.Control.Feedback type="invalid">
                Please Enter a address
              </Form.Control.Feedback> */}
            </Form.Group>
          </Row>
          <Row className="mb-3">
            <Form.Group as={Col} md="4">
              {/* <Form.Label>City</Form.Label> */}
              <Form.Control
                type="text"
                placeholder="City"
                required
                // onChange={handleChange}
                value={userData["city"]}
                onChange={(e) =>
                  setUserData({ ...userData, city: e.target.value })
                }
                // isValid={validateField('city')}
                // isInvalid={!validateField('city')}
              />
              {/* <Form.Control.Feedback type="valid">
                Looks good.!
              </Form.Control.Feedback>
              <Form.Control.Feedback type="invalid">
                Please provide a valid city.
              </Form.Control.Feedback> */}
            </Form.Group>
            <Form.Group as={Col} md="4" controlId="validationCustom04">
              {/* <Form.Label>State</Form.Label> */}
              <Form.Control
                type="text"
                placeholder="State"
                required
                // onChange={handleChange}
                value={userData["state"]}
                onChange={(e) =>
                  setUserData({ ...userData, state: e.target.value })
                }
                // isValid={validateField('state')}
                // isInvalid={!validateField('state')}
              />
              {/* <Form.Control.Feedback type="valid">
                looks good.!.
              </Form.Control.Feedback>{" "}
              <Form.Control.Feedback type="invalid">
                Please provide a valid state.
              </Form.Control.Feedback> */}
            </Form.Group>
            <Form.Group as={Col} md="4">
              {/* <Form.Label>Zip</Form.Label> */}
              <Form.Control
                type="text"
                placeholder="Zip code"
                required
                // onChange={handleChange}
                value={userData["zip"]}
                onChange={(e) =>
                  setUserData({ ...userData, zip: e.target.value })
                }
                // isValid={validateField('zip')}
                // isInvalid={!validateField('zip')}
              />
              {/* <Form.Control.Feedback type="valid">
                Looks good.!
              </Form.Control.Feedback>
              <Form.Control.Feedback type="invalid">
                Please provide a valid zip.
              </Form.Control.Feedback> */}
            </Form.Group>
          </Row>

          <Button
            style={{
              float: "right",
              paddingLeft: "4rem",
              paddingRight: "4rem",
              marginBottom: "1rem",
              backgroundColor: "rgb(25, 118, 210)",
              color: "white",
            }}
            className=" mb-3"
            type="submit"
            onClick={() => setStep(2)}
          >
            Next
          </Button>
        </Form>
      </div>
    </div>
  );
};

export default Personal;
