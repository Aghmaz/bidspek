import React from "react";
import Navbar from "./navbar";
import first from "../images/second.png";
import google from "../images/google.svg";
import emailPic from "../images/email.svg";
import linkedin from "../images/linkedin.svg";
import "./GoogleLogin.css";
import "./signin.css";
import Button from "@mui/material/Button";
import { Link } from "react-router-dom";
import { useState } from "react";
import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
import { useNavigate } from "react-router-dom";
import axios from "axios";

// const clientId = "711717933333-vf2d5qject036er2sdms5u9983mq3l0r.apps.googleusercontent.com";

const Signup = () => {
  // For Google
  const googleAuth = () => {
    window.open(
      `${process.env.REACT_APP_API_URL}/auth/google/callback`,
      "_self"
    );
  };

  // For Linkedin
  const linkedinAuth = () => {
    window.open(
      `${process.env.REACT_APP_API_URL}/auth/linkedin/callback`,
      "_self"
    );
  };

  // for email

  const [showForm, setShowForm] = useState(false);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const navigate = useNavigate();
  const handleEmailChange = (event) => {
    setEmail(event.target.value);
  };

  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };

  const handleSubmit = async (event) => {
    // console.log("herlllllllllllllllllllllllllllllllllll");
    event.preventDefault();

    try {
      const response = await axios.post(
        `${process.env.REACT_APP_API_URL}/engineer/emailregister`,
        {
          email: email,
          password: password,
        }
      );

      console.log(response.data.message);
      navigate("/");
    } catch (error) {
      console.log(error);
    }
  };
  const handleButtonClick = () => {
    setShowForm(true);
  };

  return (
    <div className="w-100" style={{ overflow: "hidden" }}>
      <Navbar />

      <div className="buttonnn">
        <Button
          style={{ paddingLeft: "2rem", paddingRight: "2rem" }}
          variant="contained"
        >
          <Link style={{ color: "white", textDecoration: "none" }} to="/login">
            Sign in
          </Link>
        </Button>
      </div>

      <div
        className="container ms-5 mt-5"
        id="mob"
        style={{ position: "absolute" }}
      >
        <h1
          style={{
            fontWeight: "800",
            fontSize: "60px",
            fontFamily: "Montserrat",
            color: "rgba(0, 0, 0, 1)",
          }}
        >
          {" "}
          Sign up
        </h1>
        <span
          style={{
            fontWeight: "400",
            fontSize: "16px",
            fontFamily: "Montserrat",
          }}
        >
          {" "}
          Don't have an account yet? Create one now!
        </span>
        <div class="col-md-12 buto mt-4">
          <div
            style={{ display: "flex", flexDirection: "column", gap: "1rem" }}
            className="mob"
          >
            {!showForm && (
              <Button
                style={{ backgroundColor: "white", color: "black" }}
                variant="contained"
              >
                <img src={emailPic} style={{ width: "2rem", height: "2rem" }} />{" "}
                <span
                  className="ms-3"
                  style={{
                    textTransform: "capitalize",
                    fontFamily: "Roboto",
                    fontSize: "1.3rem",
                    color: "rgba(0, 0, 0, 0.54)",
                  }}
                  onClick={handleButtonClick}
                >
                  {" "}
                  Sign up with Email
                </span>
              </Button>
            )}
            {showForm && (
              <form onSubmit={handleSubmit}>
                <div className="row">
                  <Form.Group as={Col} md="6">
                    <Form.Label>Email*</Form.Label>
                    <Form.Control
                      required
                      type="text"
                      value={email}
                      onChange={handleEmailChange}
                      // isValid={validateField('lastname')}
                      // isInvalid={!validateField('lastname')}
                    />
                    <Form.Control.Feedback type="valid">
                      Looks good!
                    </Form.Control.Feedback>
                    <Form.Control.Feedback type="invalid">
                      Please enter a valid Email name.
                    </Form.Control.Feedback>
                  </Form.Group>

                  <Form.Group as={Col} md="6">
                    <Form.Label>Password*</Form.Label>
                    <Form.Control
                      required
                      type="password"
                      value={password}
                      onChange={handlePasswordChange}
                      // isValid={validateField('lastname')}
                      // isInvalid={!validateField('lastname')}
                    />
                    <Form.Control.Feedback type="valid">
                      Looks good!
                    </Form.Control.Feedback>
                    <Form.Control.Feedback type="invalid">
                      Password shoud have atleast one number ,special character
                      and alphabet with minimum length 6.
                    </Form.Control.Feedback>
                  </Form.Group>
                </div>
                <Button
                  className="mt-3 w-25 "
                  type="submit"
                  variant="contained"
                  onClick={handleSubmit}
                >
                  {/* <Link style={{ color: "white", textDecoration: "none" }} > */}
                  Continue
                  {/* </Link> */}
                </Button>
              </form>
            )}
            <div class="or-container ">
              <div class="line-separator"></div> <div class="or-label">or</div>
              <div class="line-separator"></div>
            </div>
            <Button
              style={{ backgroundColor: "white", color: "black" }}
              variant="contained"
            >
              {" "}
              <img
                src={google}
                style={{ width: "2rem", height: "2rem" }}
              />{" "}
              <span
                className="ms-3"
                style={{
                  textTransform: "capitalize",
                  fontFamily: "Roboto",
                  fontSize: "1.3rem",
                  color: "rgba(0, 0, 0, 0.54)",
                }}
                onClick={googleAuth}
              >
                {" "}
                Sign up with Google
              </span>{" "}
            </Button>
            <Button
              style={{ backgroundColor: "white", color: "black" }}
              variant="contained"
            >
              <img src={linkedin} style={{ width: "2rem", height: "2rem" }} />{" "}
              <span
                className="ms-3"
                style={{
                  textTransform: "capitalize",
                  fontFamily: "Roboto",
                  fontSize: "1.3rem",
                  color: "rgba(0, 0, 0, 0.54)",
                }}
                onClick={linkedinAuth}
              >
                {" "}
                Sign up with Linkedin
              </span>
            </Button>
            <div>
              <span style={{ fontFamily: "Montserrat" }}>
                {" "}
                If Already have an Account?
                <Link
                  style={{
                    marginLeft: "0.3rem",
                    fontFamily: "Montserrat",
                    fontWeight: "600",
                    color: "black",
                  }}
                  to="/login"
                >
                  Sign in
                </Link>
              </span>
            </div>
          </div>
        </div>
      </div>
      <div className="pic">
        <img src={first} alt="Construction building" />
      </div>
    </div>
  );
};

export default Signup;
