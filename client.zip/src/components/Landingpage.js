import React from 'react'
import Navbar from './navbar';

const Landingpage = () => {
  return (
    <div>
      
<Navbar/>

    </div>
  )
}

export default Landingpage
